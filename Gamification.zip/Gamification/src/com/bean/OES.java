package com.bean;

public class OES {
	
	private int oe_Id;
	private String oe_Name;
	
	public OES() {
		super();
	}
	
	public OES(int oe_Id, String oe_Name) {
		super();
		this.oe_Id = oe_Id;
		this.oe_Name = oe_Name;
	}
	
	public int getOe_Id() {
		return oe_Id;
	}
	
	public void setOe_Id(int oe_Id) {
		this.oe_Id = oe_Id;
	}
	
	public String getOe_Name() {
		return oe_Name;
	}
	
	public void setOe_Name(String oe_Name) {
		this.oe_Name = oe_Name;
	}	
}
