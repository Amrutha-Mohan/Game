package com.bean;

public class ScoreBoard {
	private int year;
	private String bensyl_id;
	private float hours;
	private int trn_level;
	private int badge;
	private int trophy;

	public ScoreBoard() {
		super();
	}

	public ScoreBoard(int year, String bensyl_id, float hours, int trn_level, int badge, int trophy) {
		super();
		this.year = year;
		this.bensyl_id = bensyl_id;
		this.hours = hours;
		this.trn_level = trn_level;
		this.badge = badge;
		this.trophy = trophy;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getBensyl_id() {
		return bensyl_id;
	}

	public void setBensyl_id(String bensyl_id) {
		this.bensyl_id = bensyl_id;
	}

	public float getHours() {
		return hours;
	}

	public void setHours(float hours) {
		this.hours = hours;
	}

	public int getTrn_level() {
		return trn_level;
	}

	public void setTrn_level(int trn_level) {
		this.trn_level = trn_level;
	}

	public int getBadge() {
		return badge;
	}

	public void setBadge(int badge) {
		this.badge = badge;
	}

	public int getTrophy() {
		return trophy;
	}

	public void setTrophy(int trophy) {
		this.trophy = trophy;
	}
	
}
