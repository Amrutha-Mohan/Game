package com.bean;

public class TrainingDetail {
	
	private int trn_det_id;
	private String bensyl_id;
	private String trn_name;
	private float training_hour;
	private String trn_date;
	
	public TrainingDetail() {
		super();
	}

	public TrainingDetail(int trn_det_id, String bensyl_id, String trn_name, float training_hour, String trn_date) {
		super();
		this.trn_det_id = trn_det_id;
		this.bensyl_id = bensyl_id;
		this.trn_name = trn_name;
		this.training_hour = training_hour;
		this.trn_date = trn_date;
	}

	public int getTrn_det_id() {
		return trn_det_id;
	}

	public void setTrn_det_id(int trn_det_id) {
		this.trn_det_id = trn_det_id;
	}

	public String getBensyl_id() {
		return bensyl_id;
	}

	public void setBensyl_id(String bensyl_id) {
		this.bensyl_id = bensyl_id;
	}

	public String getTrn_name() {
		return trn_name;
	}

	public void setTrn_name(String trn_name) {
		this.trn_name = trn_name;
	}

	public float getTraining_hour() {
		return training_hour;
	}

	public void setTraining_hour(float training_hour) {
		this.training_hour = training_hour;
	}

	public String getTrn_date() {
		return trn_date;
	}

	public void setTrn_date(String trn_date) {
		this.trn_date = trn_date;
	}	
	
}
