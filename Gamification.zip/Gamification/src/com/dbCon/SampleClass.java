package com.dbCon;

import java.sql.*;

public class SampleClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		String trn_year="2018";
		int count=0;
		System.out.println("creating scoreboard");

				//Connection con=null;
		PreparedStatement pstmt=null, pstmt2=null, pstmt3=null;
		ResultSet rs=null, rs3=null, rs4=null;
		int trn_level=0, badge=0, trophy=0;

		String bensyl_id="";
		String sql="", sql2="", sql3="", sql4="", sql5="";
		DBConnection dbCon=new DBConnection();

		try{
					//con=dataSource.getConnection();
			int result=0;
			float TotHour;
			sql="select distinct bensyl_id from game_training_detail where trn_year=?"; 
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, trn_year);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				TotHour=0.0f;
				trn_level=0;
				badge=0;
				trophy=0;
				bensyl_id=rs.getString("bensyl_id");
				sql3="select training_hour from game_training_detail where bensyl_id=? and trn_year=?";
						//pstmt3=con.prepareStatement(sql3);
				pstmt3=dbCon.getStatement(sql3);
				pstmt3.setString(1, bensyl_id);
				pstmt3.setString(2, trn_year);
				rs3=pstmt3.executeQuery();
				while(rs3.next())
				{
					TotHour=(TotHour+(rs3.getFloat("training_hour")));
				}
				if(TotHour>=40){
					badge=1;					
				}
				if(TotHour<40){
					trn_level=0;
				}
				else if(TotHour>=40 && TotHour<150){
					trn_level=1;
				}
				else if(TotHour>=150 && TotHour<300){
					trn_level=2;
				}
				else if(TotHour>=300 && TotHour<500){
					trn_level=3;
				}
				else if(TotHour>=500){
					trophy=1;
					trn_level=4;
					int val=(int) (TotHour-500);
					val=val/250;
					badge+=val;
				}

				sql4="select hours from game_scoreboard where trn_year=? and bensyl_id=?";
						//pstmt2=con.prepareStatement(sql4);
				pstmt2=dbCon.getStatement(sql4);
				pstmt2.setString(1, trn_year);
				pstmt2.setString(2, bensyl_id);
				rs4=pstmt2.executeQuery();

				sql2="update game_scoreboard set hours=?,trn_level=?,badge=?,trophy=? where trn_year=? and bensyl_id=?";
				sql5="insert into game_scoreboard values(?,?,?,?,?,?)";
				if(rs4.next()){
							//pstmt2=con.prepareStatement(sql2);
					pstmt2=dbCon.getStatement(sql2);
					pstmt2.setFloat(1, TotHour);
					pstmt2.setInt(2,trn_level);
					pstmt2.setInt(3,badge);
					pstmt2.setInt(4,trophy);
					pstmt2.setString(5,trn_year);
					pstmt2.setString(6,bensyl_id);
					result=pstmt2.executeUpdate();
					System.out.println(++count);
				}
				else{
							//pstmt2=con.prepareStatement(sql5);
					pstmt2=dbCon.getStatement(sql5);
					pstmt2.setString(1,trn_year);
					pstmt2.setString(2,bensyl_id);
					pstmt2.setFloat(3, TotHour);
					pstmt2.setInt(4,trn_level);
					pstmt2.setInt(5,badge);
					pstmt2.setInt(6,trophy);
					result=pstmt2.executeUpdate();
					System.out.println(++count);
				}				
			}
			
			System.out.println("completed scoreboard");

		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
						//con.close();
				if(pstmt!=null){
					pstmt.close();
				}
				if(pstmt2!=null){
					pstmt2.close();
				}
				if(pstmt3!=null){
					pstmt2.close();
				}
				if(rs!=null){
					rs.close();
				}
				if(rs3!=null){
					rs3.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
		
	}

}
