package com.connectionDao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.sql.DataSource;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.dbCon.DBConnection;


public class UploadDao {

			//private DataSource dataSource;

	public UploadDao() {
		super();
	}

			/*public UploadDao(DataSource dataSource) {
				super();
				this.dataSource = dataSource;
			}*/

	public int uploadExcel(String trn_year, String fileName) throws SQLException {

		Set<String> empSet;

		int result=0;
		Float hour=0.0f;
		String sql="";
				//Connection con=null;
		PreparedStatement pstmt=null;

		int FR=1;
		int FC = 0;
		int LC = 9;
		DBConnection dbCon=new DBConnection();


		try {
			empSet=getAllBensyl();
			deleteTables(trn_year);
			System.out.println("start uploading");

			FileInputStream fStream = new FileInputStream(fileName);
			POIFSFileSystem fSystem = new POIFSFileSystem(fStream);
			HSSFWorkbook workBook = new HSSFWorkbook(fSystem);
			HSSFSheet mySheet = workBook.getSheetAt(0);
					//con=dataSource.getConnection();
			for (int i = FR;; i++) {
				List<HSSFCell> cellHolder = new ArrayList<HSSFCell>();
				HSSFRow r = mySheet.getRow(i);
				if(r!=null){
					for (int j = FC; j <= LC; j++) {
						HSSFCell c = r.getCell(j);
						cellHolder.add(c);
					}
				}
				else{
					break;
				}				

				//insert into training_details
				sql="insert into game_training_detail(bensyl_id,trn_name,training_hour,trn_date,trn_year) values(?,?,?,?,?)";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, (((HSSFCell) cellHolder.get(1)).toString()).toUpperCase());
				pstmt.setString(2, ((HSSFCell) cellHolder.get(7)).toString());
				hour=Float.parseFloat(((HSSFCell) cellHolder.get(9)).toString());
				pstmt.setFloat(3, hour);
				pstmt.setString(4, ((HSSFCell) cellHolder.get(8)).toString());
				pstmt.setString(5, trn_year);
				result=pstmt.executeUpdate();

				String bensyl_id=(((HSSFCell) cellHolder.get(1)).toString()).toUpperCase();	
				if(empSet.contains(bensyl_id)){
					//okay
				}
				else{
					empSet.add(bensyl_id);
					//call a method to add an employee if not in employee table
					String emp_name=((HSSFCell) cellHolder.get(2)).toString();
					String linemng_id=((HSSFCell) cellHolder.get(5)).toString();
					String oe_name=((HSSFCell) cellHolder.get(4)).toString();
					addEmployee(emp_name,linemng_id,oe_name,bensyl_id);
				}
			}

			//call method to update score board
			createScoreBoard(trn_year);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
		}
		return 1;
	}

	private void addEmployee(String emp_name, String linemng_id, String oe_name, String bensyl_id) throws SQLException {

				//Connection con=null;
		PreparedStatement pstmt2=null, pstmt3=null;
		ResultSet  rs3=null;
		String sql1="", sql2="";
		int oe_id=0, result=0;
		DBConnection dbCon=new DBConnection();
		System.out.println("add employee if not already added");

		try {

					//con=dataSource.getConnection();
			sql1="select oe_id from game_oes where oe_name=?";
					//pstmt2=con.prepareStatement(sql1);
			pstmt2=dbCon.getStatement(sql1);
			pstmt2.setString(1, oe_name);
			rs3=pstmt2.executeQuery();
			if(rs3.next()){
				oe_id=rs3.getInt("oe_id");
			}
			sql2="insert into game_employee(emp_name,linemng_id,status,oe_id,bensyl_id) values(?,?,?,?,?)";
					//pstmt3=con.prepareStatement(sql2);
			pstmt3=dbCon.getStatement(sql2);
			pstmt3.setString(1, emp_name);
			pstmt3.setString(2, linemng_id);
			pstmt3.setString(3, "notActive");
			pstmt3.setInt(4, oe_id);
			pstmt3.setString(5, bensyl_id);
			result=pstmt3.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			if(pstmt2!=null){
				pstmt2.close();
			}
			if(rs3!=null){
				rs3.close();
			}
			if(pstmt3!=null){
				pstmt3.close();
			}
		}

	}

	public Set<String> getAllBensyl() throws SQLException{

				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql1="";
		Set<String> empSet=new TreeSet<String>();
		DBConnection dbCon=new DBConnection();
		System.out.println("get all bensyl IDS");

		try {

					//con=dataSource.getConnection();
			sql1="select bensyl_id from game_employee";
					//pstmt=con.prepareStatement(sql1);
			pstmt=dbCon.getStatement(sql1);
			rs=pstmt.executeQuery();
			while(rs.next()){
				empSet.add(rs.getString("bensyl_id"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs.close();
		}
		return empSet;
	}

	public void createScoreBoard(String trn_year) {

		System.out.println("creating scoreboard");

				//Connection con=null;
		PreparedStatement pstmt=null, pstmt2=null, pstmt3=null;
		ResultSet rs=null, rs3=null, rs4=null;
		int trn_level=0, badge=0, trophy=0;

		String bensyl_id="";
		String sql="", sql2="", sql3="", sql4="", sql5="";
		DBConnection dbCon=new DBConnection();

		try{
					//con=dataSource.getConnection();
			int result=0;
			float TotHour;
			sql="select distinct bensyl_id from game_training_detail where trn_year=?"; 
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, trn_year);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				TotHour=0.0f;
				trn_level=0;
				badge=0;
				trophy=0;
				bensyl_id=rs.getString("bensyl_id");
				sql3="select training_hour from game_training_detail where bensyl_id=? and trn_year=?";
						//pstmt3=con.prepareStatement(sql3);
				pstmt3=dbCon.getStatement(sql3);
				pstmt3.setString(1, bensyl_id);
				pstmt3.setString(2, trn_year);
				rs3=pstmt3.executeQuery();
				while(rs3.next())
				{
					TotHour=(TotHour+(rs3.getFloat("training_hour")));
				}
				if(TotHour>=40){
					badge=1;					
				}
				if(TotHour<40){
					trn_level=0;
				}
				else if(TotHour>=40 && TotHour<150){
					trn_level=1;
				}
				else if(TotHour>=150 && TotHour<300){
					trn_level=2;
				}
				else if(TotHour>=300 && TotHour<500){
					trn_level=3;
				}
				else if(TotHour>=500){
					trophy=1;
					trn_level=4;
					int val=(int) (TotHour-500);
					val=val/250;
					badge+=val;
				}

				sql4="select hours from game_scoreboard where trn_year=? and bensyl_id=?";
						//pstmt2=con.prepareStatement(sql4);
				pstmt2=dbCon.getStatement(sql4);
				pstmt2.setString(1, trn_year);
				pstmt2.setString(2, bensyl_id);
				rs4=pstmt2.executeQuery();

				sql2="update game_scoreboard set hours=?,trn_level=?,badge=?,trophy=? where trn_year=? and bensyl_id=?";
				sql5="insert into game_scoreboard values(?,?,?,?,?,?)";
				if(rs4.next()){
							//pstmt2=con.prepareStatement(sql2);
					pstmt2=dbCon.getStatement(sql2);
					pstmt2.setFloat(1, TotHour);
					pstmt2.setInt(2,trn_level);
					pstmt2.setInt(3,badge);
					pstmt2.setInt(4,trophy);
					pstmt2.setString(5,trn_year);
					pstmt2.setString(6,bensyl_id);
					result=pstmt2.executeUpdate();
				}
				else{
							//pstmt2=con.prepareStatement(sql5);
					pstmt2=dbCon.getStatement(sql5);
					pstmt2.setString(1,trn_year);
					pstmt2.setString(2,bensyl_id);
					pstmt2.setFloat(3, TotHour);
					pstmt2.setInt(4,trn_level);
					pstmt2.setInt(5,badge);
					pstmt2.setInt(6,trophy);
					result=pstmt2.executeUpdate();
				}				
			}

		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
						//con.close();
				if(pstmt!=null){
					pstmt.close();
				}
				if(pstmt2!=null){
					pstmt2.close();
				}
				if(pstmt3!=null){
					pstmt2.close();
				}
				if(rs!=null){
					rs.close();
				}
				if(rs3!=null){
					rs3.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteTables(String trn_year) throws SQLException{

		System.out.println("deleting tables");
				//Connection con=null;
		PreparedStatement pstmt=null;
		String sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();

		try {
					//con=dataSource.getConnection();
			sql="delete from game_training_detail where trn_year=?";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, trn_year);
			result=pstmt.executeUpdate();		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
		}
	}


}
