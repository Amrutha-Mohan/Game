package com.connectionDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

/*import com.bean.Admin;
import com.bean.Employee;*/
import com.bean.LogIn;
import com.dbCon.DBConnection;

public class CredentialDao {
	
			//private DataSource dataSource;

	public CredentialDao() {
		super();
	}

			/*public CredentialDao(DataSource dataSource) {
				super();
				this.dataSource = dataSource;
			}*/

	public String[] login(LogIn objLog) throws SQLException {
		
				//Connection con= null;
		PreparedStatement pstmt1= null,pstmt2= null,pstmt=null;
		ResultSet rs1=null,rs2=null,rs3=null,rs4=null;
		String sql1="", sql2="",sql="";
		String[] msg=new String[2];
		DBConnection dbCon=new DBConnection();
		
		try {
			
			sql1="select emp_email from game_admin where emp_email=? and password=?";
			sql2="select * from game_employee where bensyl_id=? and password=? and status='Active'";		
					//con=dataSource.getConnection();
			
					//pstmt1=con.prepareStatement(sql1);
			pstmt1=dbCon.getStatement(sql1);
			pstmt1.setString(1,objLog.getUname());
			pstmt1.setString(2,objLog.getPass());
			rs1=pstmt1.executeQuery();
			
					//pstmt2=con.prepareStatement(sql2);
			pstmt2=dbCon.getStatement(sql2);
			pstmt2.setString(1,objLog.getUname().toUpperCase());
			pstmt2.setString(2,objLog.getPass());
			rs2=pstmt2.executeQuery();
			
			if(rs1.next()){
				sql="select emp_name from game_employee where emp_email=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objLog.getUname());
				rs3=pstmt.executeQuery();
				if(rs3.next()){
					msg[1]=rs3.getString("emp_name");
				}
				msg[0]="admin";
			}
			else if(rs2.next()){
				sql="select emp_name from game_employee where bensyl_id=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objLog.getUname().toUpperCase());
				rs4=pstmt.executeQuery();
				if(rs4.next()){
					msg[1]=rs4.getString("emp_name");
				}
				msg[0]="employee";
			}
			else if((!rs1.next()) && (!rs2.next())){
				msg[0]="invalid";
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally {
					/*if(con!=null){
						con.close();
					}*/
			if(pstmt1!=null){
				pstmt1.close();
			}
			if(pstmt2!=null){
				pstmt2.close();
			}
			if(rs1!=null){
				rs1.close();
			}
			if(rs2!=null){
				rs2.close();
			}
			if(rs3!=null){
				rs3.close();
			}
			if(rs4!=null){
				rs4.close();
			}
		}
		return msg;
	}
}
