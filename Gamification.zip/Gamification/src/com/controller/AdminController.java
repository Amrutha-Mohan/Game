package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.Admin;
import com.bean.Employee;
import com.connectionDao.AdminDao;

/**
 * Servlet implementation class AdminController
 */
@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private AdminDao admDao;

			/*@Resource(name="gameDB")
			private DataSource dataSource;*/
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
				//admDao=new AdminDao(dataSource);
		admDao=new AdminDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("admChange")){
			changePass(request,response);
		}
		else if(cmd.equals("oldPA")){
			adminPassCheck(request,response);
		}
		
	}

	private void changePass(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		HttpSession session = request.getSession(false);
		String emp_email=(String)session.getAttribute("uname");
		String newPass=request.getParameter("newpass1");
		Admin admin=new Admin(emp_email,newPass);
		
		try {
			PrintWriter pw= response.getWriter();
			msg=admDao.changePass(admin);
			if(msg.equals("notChanged")){
				request.setAttribute("changeErr","Password not changed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("changed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Password Changed. Login with New Password');");
				pw.println("location='index.jsp';");
				pw.println("</script>");
			}				
				
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private void adminPassCheck(HttpServletRequest request, HttpServletResponse response) {
		
		int result=0;
		Admin admObj=new Admin();
		HttpSession session = request.getSession(false);
		String emp_email=(String)session.getAttribute("uname");
		admObj.setPassword(request.getParameter("pass"));
		admObj.setEmp_email(emp_email);
		try {
			
			PrintWriter pw=response.getWriter();
			result=admDao.passwordCheck(admObj);
			if(result == -1){
				pw.println("Wrong Password");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
