package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Profile
 */
@WebServlet("/Profile")
public class Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String bnesylID=request.getParameter("id");
		float hour=0.0f;
		int badge=0,level=0,trophy=0;
		
		bnesylID=bnesylID.toUpperCase();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@sla18326:1521:ukahp1d", "AZT_TRN", "Azt_trn1#");
			String query="select * from game_scoreboard where bensyl_id=?";  
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, bnesylID);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				hour=rs.getFloat("hours");
				level=rs.getInt("trn_level");
				badge=rs.getInt("badge");
				trophy=rs.getInt("trophy");
			}
			response.getWriter().append("{\r\n  \"id\": \""+bnesylID+"\",\r\n  \"hours\": \""+hour+"\",\r\n  \"badge\": \""+badge+"\",\r\n  \"trophy\": \""+trophy+"\",\r\n  \"level\": \""+level+"\"\r\n}");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
